package veicoli;

public abstract class Veicolo {

	protected String marca;
	
	protected int anno;
	
	protected int cilindrata;
	
	protected Veicolo(String marca, int anno, int cilindrata) {
		this.marca = marca;
		this.anno = anno;
		this.cilindrata = cilindrata;
	}

	@Override
	public String toString() {
		return "marca\t\t->\t" + marca + "\nanno\t\t->\t" + anno + "\ncilindrata\t\t->\t" + cilindrata;
	}
	
	
}
