package veicoli;

public class Furgone extends Veicolo{

	private int capacita;
	
	public Furgone(String marca, int anno, int cilindrata, int cap) {
		super(marca, anno, cilindrata);
		capacita = cap;
	}

	@Override
	public String toString() {
		return "Furgone\n" + super.toString() + "\ncapacità\t->\t" 
				+ capacita + " l";
	}

}
