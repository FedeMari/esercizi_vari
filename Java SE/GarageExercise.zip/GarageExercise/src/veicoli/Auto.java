package veicoli;

public class Auto extends Veicolo{

	private int nPorte;
	
	private String alimentazione;
	
	public Auto(String marca, int anno, int cilindrata, int nPorte, String tipoAlim) {
		super(marca, anno, cilindrata);
		this.nPorte = nPorte;
		alimentazione = tipoAlim;
	}

	@Override
	public String toString() {
		return "Auto\n" + super.toString() + "\nnumeroPorte\t->\t" 
				+ nPorte + "\nalimentazione\t->\t" + alimentazione;
	}
	
}
