package veicoli;

public class Moto extends Veicolo{

	private int tempi;
	
	public Moto(String marca, int anno, int cilindrata, int nTempi) {
		super(marca, anno, cilindrata);
		tempi = nTempi;
	}

	@Override
	public String toString() {
		return "Moto\n" + super.toString() + "\nnumeroTempi\t->\t" 
				+ tempi;
	}

	
	
}
