package garage;

import veicoli.Veicolo;

public class Garage {

	private Veicolo[] posti;
	
	public Garage() {
		posti = new Veicolo[15];
	}
	
	public boolean addVeicolo(Veicolo v, int posizione) {
		if(posizione < 0 || posizione >= posti.length)
			return false;
		
		if(posti[posizione] != null) {
			return false;
		}
		
		posti[posizione] = v;
		return true;
	}
	
	public int addVeicolo(Veicolo v) {
		for(int i = 0; i < posti.length; i++) {
			if(posti[i] == null) {
				posti[i] = v;
				return i;
			}
		}
		return -1;
	}
	
	public Veicolo removeVeicolo(int posizione) {
		Veicolo v = posti[posizione];
		posti[posizione] = null;
		return v;
	}
	
	public void stampaSituazione() {
		System.out.println("Situazione Garage");
		for(int i = 0; i < posti.length; i++) {
			System.out.print("Posto " + i + ": \t");
			if(posti[i] != null) {
				System.out.println("Posto occupato");
			}else
				System.out.println("Posto Libero");
		}
	}
	
	
}
