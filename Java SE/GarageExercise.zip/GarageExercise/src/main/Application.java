package main;

import java.util.Scanner;

import garage.Garage;
import veicoli.Auto;
import veicoli.Furgone;
import veicoli.Moto;
import veicoli.Veicolo;

public class Application {

	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {

		Garage garage = new Garage();
		int operazione = 0;

		while (operazione != -1) {

			System.out.println("Cosa vuoi fare?");
			System.out.println("1)Inserisci un veicolo nel garage");
			System.out.println("2)Rimuovi un veicolo dal garage");
			System.out.println("3)Stampa la situazione del garage");
			System.out.println("-1)Esci dal programma");

			operazione = in.nextInt();

			switch (operazione) {

			case 1:
				Veicolo v = createVeicolo();
				System.out.println("In che poszione vuoi inserire il veicolo? (0-14), (-1 per posizione predefinita)");
				int pos = in.nextInt();

				if (!garage.addVeicolo(v, pos))
					pos = garage.addVeicolo(v);
				
				if(pos != -1)
					System.out.println("Veicolo inserito in posizione " + pos);
				else
					System.out.println("Il Garage è pienozzo");
				break;
				
			case 2:
				System.out.println("Da quale posizione vuoi rimuovere il veicolo? (0-14)");
				pos = in.nextInt();
				v = garage.removeVeicolo(pos);
				if(v != null) {
					System.out.println(v);
				}
				else {
					System.out.println("Non c'è un veicolo in quella posizione");
				}
				break;
			case 3:
				garage.stampaSituazione();
				break;
			case -1:
				System.out.println("è stato un piacere, a mai più, Nio!");
				break;
			default:
				System.out.println("Operazione no valida");
				
			}

		}

	}

	private static Veicolo createVeicolo() {
		System.out.println("Che tipo di veicolo vuoi inserire? (Auto (1), Moto (2), Furgone(3))");
		int scelta = in.nextInt();
		Veicolo v = null;

		System.out.println("Quale è la marca del veicolo?");
		String marca = in.next();
		System.out.println("Quale è l'anno di immatricolazione?");
		int anno = in.nextInt();
		System.out.println("Quanti cilindri ha il veicolo?");
		int cilindri = in.nextInt();

		switch (scelta) {
		case 1:
			System.out.println("Quante porte ha l'auto?");
			int nPorte = in.nextInt();
			System.out.println("Che tipo di alimentazione usa? (Diesel/Benzina)");
			String alim = in.next();
			v = new Auto(marca, anno, cilindri, nPorte, alim);
			break;
		case 2:
			System.out.println("Quanti tempi ha il motore della moto?");
			int tempi = in.nextInt();
			v = new Moto(marca, anno, cilindri, tempi);
			break;
		case 3:
			System.out.println("Quanta e' la capacità del furgone? (Litri)");
			int cap = in.nextInt();
			v = new Furgone(marca, anno, cilindri, cap);
			break;
		default:

		}

		return v;
	}

}
