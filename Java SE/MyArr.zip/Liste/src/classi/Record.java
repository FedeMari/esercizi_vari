package classi;

public class Record <T>{
	Record<T> next;
	T data;
	public void add(T elem) {
		if(next == null) {
			setData(elem);
		}else {
			
		}
		
	}
	public Record<T> getNext() {
		return next;
	}
	public void setNext(Record<T> next) {
		this.next = next;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
}
