package main;

import java.util.List;

import classi.MyArrayList;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyArrayList<Integer> list = new MyArrayList<Integer>(8);
		list.addAll(List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
		System.out.println("dimensione: " + list.size() + " capacita: " + list.capacity());
		for (int i = 0; i < 3; i++) {
			list.removeAT(1);
		}
		System.out.println("dimensione: " + list.size() + " capacita: " + list.capacity());
		list.setElem(9,1);
		System.out.println(list);

	}

}
